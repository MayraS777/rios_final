function Pantalones (props){
    return(
        <section>
            <img src={props.imagen} alt={props.nombre}/>
            <h2>{props.nombre}</h2>
            <p>{props.categoria}</p>
            <p>{props.precio}</p>
            <h4>{props.cuotas}</h4>
        </section>
    );
}

export default Pantalones;