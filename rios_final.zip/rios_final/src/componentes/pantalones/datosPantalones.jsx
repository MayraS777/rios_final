const pantalon = [
    {
    nombre: 'JORGELIA DENIM',
    categoria: 'Pantalon',
    precio: '$35.000',
    cuotas:'Hasta 6 cuotas sin interes', 
    imagen:'images/jorgelia.jpg',

},
{
    nombre: 'CHARLOTTE DENIM',
    categoria: 'Pantalon',
    precio: '$40.000',
    cuotas:'Hasta 6 cuotas sin interes', 
    imagen:'images/charlotte.jpg',
},
{
    nombre: 'PAOLO DENIM',
    categoria: 'Pantalon',
    precio: '$43.000',
    cuotas:'Hasta 6 cuotas sin interes', 
    imagen:'images/paolo.jpg',
}
];

export default pantalon;
