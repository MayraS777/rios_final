import Boton from '../boton/boton';
import Pantalones from './Pantalones';
import pantalon from './datosPantalones';

function ListaPantalones(){
    return(
        <div>
            {pantalon.map((pantalon, index) => (
                <Pantalones
                key = {index}
                nombre = {pantalon.nombre}
                categoria = {pantalon.categoria}
                precio = {pantalon.precio}
                cuotas = {pantalon.cuotas}
                imagen = {pantalon.imagen}
                />
            ))}
            
        </div>
    )
}

export default ListaPantalones;