import './Header.css';
import portada from '../../assets/img/portada.jpg'

function Header() {

  return (
    <header className='header'>
        <h1>Bienvenidos a LouisClinton Denim</h1>
    </header>
  )
}

export default Header;
