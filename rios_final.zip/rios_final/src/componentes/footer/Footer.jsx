import './Footer.css';


function Footer() {

  return (
    <footer className='footer'>
        <p>Buenos Aires, Argentina 2024</p>
    </footer>
  )
}

export default Footer;
