import './Section.css';
import denim from '../../assets/img/denim.jpg'
import Boton from '../boton/boton';

const handlerClickBoton = () => {
    alert ('!Su suscripcion fue exitosa!');
}
const handlerClickkBoton = () => {
  alert ('Se inicio correctamente');
}  


function Section() {

  return (
    <section className='section'>
        <h2>SOMOS UN EMPRENDIMIENTO LIDER DENIM EN ARGENTINA</h2>
        <p>Fabricamos los mejores articulos denim de todo Argentina.
          Realizamos jeans, camperas, shorts y polleras de alta calidad y costura.
        Contamos con un equipo de diseñadores que explotan su arte en cada una de nuestra indumentaria.
        </p>
        <img src={denim} alt="Denim" />
        <h4>¡Suscribite a nuestro WebSite para recibir todas nuestras novedades y descuentos!</h4>

        <table className='formulario'>
          <label> Nombre: </label>
          <input type="text" />
        <hr />
        <label> Apellido: </label>
        <input type="text" />
        <hr />
        <label> Email: </label>
        <input type="email" />
        <hr />
        <label> Celular: </label>
        <input type="number" />
        <hr />
    <Boton texto= "Suscribirme" onClick = {handlerClickBoton} />
   </table>
   <h4> Si ya estas registrado ingresa a tu cuenta y comenza a llenar tu carrito!</h4>
   <table className='formulario'>
        <label> Email: </label>
        <input type="email" />
        <hr />
        <label> Contraseña: </label>
        <input type="password" />
        <hr />
    <Boton texto= "Ingresar" onClick = {handlerClickkBoton} />
   </table>
  
  </section>

  )
}

export default Section;
