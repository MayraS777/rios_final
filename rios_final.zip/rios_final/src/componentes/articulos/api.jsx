export const fetchArticulos = async()=>{
    const BASE_URL = 'http://hp-api.onrender.com/api/characters';

    try {
        const response = await fetch(BASE_URL);
        const data = await response.json();
        return data;
    } catch(error){
        console.error("Error fetch data", error);
        throw error;
    };
}