import { useEffect, useState } from "react";
import { fetchArticulos } from "./api";


function ListaArticulos(params) {
    const [articulos, setArtciulos] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
    const fetchData = async () => {
        try{
            const data = await fetchArticulos();
            setArtciulos(data);
            setLoading(false);
        } catch (error) {
            console.error(error)
                setLoading(false);
            }
        };

    fetchData();
}, []);
    return(
        <div>
        <h2>Lista Articulos</h2>
        <p>Listado Articulos</p>
        { loading ? (
            <p>Cargando Articulos...</p>
        ) : (
            <ul className="lista-articulos">
                {articulos.map((articulos) =>(
                    <li key={articulos.nombre} className="articulo-item">
                        <h3> {articulos.name} </h3>
                        <p>Pantalon: {articulos.nombre} </p>
                        <p>Campera: {articulos.nombre}</p>
                    </li>
                ))}
            </ul>
        )}
        </div>
);
}

export default ListaArticulos;