const camperas = [
{
    nombre: 'LAIKA DENIM',
    categoria: 'Campera',
    precio: '$32.000',
    cuotas:'Hasta 6 cuotas sin interes', 
    imagen:'images/laika.jpg',
},
{
    nombre: 'PEYTON DENIM',
    categoria: 'Campera',
    precio: '$42.000',
    cuotas:'Hasta 6 cuotas sin interes', 
    imagen:'images/peyton.jpg',
},
{
    nombre: 'CALIFORNIA DENIM',
    categoria: 'Campera',
    precio: '$38.000',
    cuotas:'Hasta 6 cuotas sin interes', 
    imagen:'images/california.jpg',
},
{
    nombre: 'ZARA DENIM',
    categoria: 'Campera',
    precio: '$36.000',
    cuotas:'Hasta 6 cuotas sin interes', 
    imagen:'images/zara.jpg',
},
];

export default camperas;
