import Campera from './Campera';
import camperas from './datosCamperas';

function ListaCamperas(){
    return(
        <div>
            {camperas.map((camperas, index) => (
                <Campera
                key = {index}
                nombre = {camperas.nombre}
                categoria = {camperas.categoria}
                precio = {camperas.precio}
                cuotas = {camperas.cuotas}
                imagen = {camperas.imagen}
                />
            ))}
        </div>
    )
}
export default ListaCamperas;