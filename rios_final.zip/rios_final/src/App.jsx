import './App.css'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Footer from './componentes/footer/Footer'
import Header from './componentes/header/Header'
import Menu from './componentes/menu/Menu'
import Section from './componentes/section/Section'
import ListaPantalones from './componentes/pantalones/ListaPantalones'
import ListaCamperas from './componentes/camperas/ListaCamperas'

function App() {

  return (
    <Router>
      <div className='container'>
<Header/>
<Menu/>
<main>
  <Routes>
    <Route path="/" element={<Section/>}/>
    <Route path="/pantalones" element={<ListaPantalones/>}/>
    <Route path="/camperas" element={<ListaCamperas/>}/>
  </Routes>
</main>
<Footer/>
</div>
    </Router>
  );
}

export default App;
